
-------------------------------------------------------------------------
# Version 01
-------------------------------------------------------------------------

############ Notes: --------------------

# Sensors are a special type of Operator that are designed to do exactly one 
# thing - wait for something to occur.

# In Apache Airflow, sensors are a type of operator that waits for a certain condition or external event to occur before proceeding with the execution of a task or a workflow. Sensors are useful when you want to pause the execution until a specific condition is met or an external system indicates that some condition has been satisfied.

# Sensors in Apache Airflow provide a way to monitor and react to changes or events from various sources, such as files, databases, APIs, or external systems. They continuously evaluate the specified condition or wait for the event to occur, allowing the workflow to progress when the condition is met.

############ Notes: --------------------

# Let's run a very simple file sensor which looks for a single file

# Create a folder called tmp/ under airflow/

# airflow/tmp/ should initially be empty

# simple_file_sensor.py

from datetime import datetime, timedelta
from airflow.utils.dates import days_ago
import pandas as pd

from airflow import DAG

from airflow.operators.python import PythonOperator
from airflow.sensors.filesystem import FileSensor


default_args = {
   'owner': 'loonycorn'
}

with DAG(
    dag_id = 'simple_file_sensor',
    description = 'Running a simple file sensor',
    default_args = default_args,
    start_date = days_ago(1),
    schedule_interval = '@once',
    tags = ['python', 'sensor', 'file sensor'],
) as dag:

    checking_for_file = FileSensor(
        task_id = 'checking_for_file',
        filepath = '/Users/loonycorn/airflow/tmp/laptops.csv',
        poke_interval = 10,
        timeout = 60 * 10
    )


    checking_for_file


# Go to the airflow UI

# Go to 

Admin -> Connections

# Search for fs_default and show this (this is what the file sensor uses)

# Go to the Grid view

# Unpause and trigger the DAG

# It'll keep waiting for the file to be present

# Click through to the Logs and show it keeps poking and waiting

# Now drag the laptop.csv file to the tmp/ folder

# Immediately switch over to the UI

# Show the task is complete

# Show the logs


-------------------------------------------------------------------------
# Version 02
-------------------------------------------------------------------------

# Delete the laptops.csv file from tmp/


from datetime import datetime, timedelta
from airflow.utils.dates import days_ago
import pandas as pd

from airflow import DAG

from airflow.operators.python import PythonOperator
from airflow.sensors.filesystem import FileSensor


default_args = {
   'owner': 'loonycorn'
}

FILE_PATH = '/Users/loonycorn/airflow/tmp/laptops.csv'
FILE_COLS = ['Id', 'Company', 'Product', 'TypeName', 'Price_euros']

def display_data():

    df = pd.read_csv(FILE_PATH, usecols=FILE_COLS)

    print(df)


with DAG(
    dag_id = 'simple_file_sensor',
    description = 'Running a simple file sensor',
    default_args = default_args,
    start_date = days_ago(1),
    schedule_interval = '@once',
    tags = ['python', 'sensor', 'file sensor'],
) as dag:

    checking_for_file = FileSensor(
        task_id = 'checking_for_file',
        filepath = FILE_PATH,
        poke_interval = 10,
        timeout = 60 * 10
    )

    display_data = PythonOperator(
        task_id = 'display_data',
        python_callable = display_data
    )

    checking_for_file >> display_data


# Go to the airflow UI

# Go to 

Admin -> Connections

# Search for fs_default and show this (this is what the file sensor uses)

# Go to the Graph view

# Trigger the DAG

# It'll keep waiting for the file to be present

# Click through to the Logs and show it keeps poking and waiting

# Now drag the laptop.csv file to the tmp/ folder

# Immediately switch over to the UI

# Show the task is complete

# IMPORTANT: Show the logs of BOTH tasks




-------------------------------------------------------------------------
# Version 03
-------------------------------------------------------------------------


# Go to the terminal where you have logged in with psql

CREATE DATABASE laptop_db;

$ \c laptop_db

# From the top navigation bar click "Admin" -> "Connections"


# Click on "+" button

Connection Id -> postgres_connection_laptop_db
Connection Type -> Postgres
Host -> localhost
Schema -> laptop_db
Login -> loonycorn
Password -> password
Port -> 5432

# Click "Test" to check if the parameters provided are correct. We get
# the following output

# Connection successfully tested

# Click "Save"

-----------------------------------

# Under airflow/sql_statements show this file

# create_table_laptop.sql
CREATE TABLE IF NOT EXISTS laptops (
    id SERIAL PRIMARY KEY,
    company VARCHAR(255),
    product VARCHAR(255),
    type_name VARCHAR(255),
    price_euros NUMERIC(10, 2)
);



# pipeline_with_file_sensor.py

# from datetime import datetime, timedelta
import pandas as pd
import psycopg2
import glob

from airflow import DAG
from airflow.utils.dates import days_ago
from airflow.operators.python import PythonOperator
from airflow.operators.bash import BashOperator
from airflow.providers.postgres.operators.postgres import PostgresOperator
from airflow.sensors.filesystem import FileSensor


default_args = {
   'owner': 'loonycorn'
}

FILE_PATH = '/Users/loonycorn/airflow/tmp/laptops_*.csv'
FILE_COLS = ['Id', 'Company', 'Product', 'TypeName', 'Price_euros']

OUTPUT_FILE = '/Users/loonycorn/airflow/output/{}.csv'

def insert_laptop_data():
    conn = psycopg2.connect(
        host="localhost",
        database="laptop_db",
        user="loonycorn",
        password="password"
    )

    cur = conn.cursor()

    for file in glob.glob(FILE_PATH):
        df = pd.read_csv(file, usecols=FILE_COLS)

        records = df.to_dict('records')
        
        for record in records:
            query = f"""INSERT INTO laptops 
                        (id, company, product, type_name, price_euros) 
                        VALUES (
                            {record['Id']}, 
                            '{record['Company']}', 
                            '{record['Product']}', 
                            '{record['TypeName']}', 
                            {record['Price_euros']})
                    """

            cur.execute(query)

    conn.commit()

    cur.close()
    conn.close()

def filter_gaming_laptops():
    for file in glob.glob(FILE_PATH):

        df = pd.read_csv(file, usecols=FILE_COLS)
        
        gaming_laptops_df = df[df['TypeName'] == 'Gaming']
        
        gaming_laptops_df.to_csv(OUTPUT_FILE.format('gaming_laptops'), 
            mode='a', header=False, index=False)

def filter_notebook_laptops():
    for file in glob.glob(FILE_PATH):

        df = pd.read_csv(file, usecols=FILE_COLS)
        
        notebook_laptops_df = df[df['TypeName'] == 'Notebook']

        notebook_laptops_df.to_csv(OUTPUT_FILE.format('notebook_laptops'), 
            mode='a', header=False, index=False)

def filter_ultrabook_laptops():
    for file in glob.glob(FILE_PATH):

        df = pd.read_csv(file, usecols=FILE_COLS)
        
        ultrabook_laptops_df = df[df['TypeName'] == 'Ultrabook']

        ultrabook_laptops_df.to_csv(OUTPUT_FILE.format('ultrabook_laptops'), 
            mode='a', header=False, index=False)


with DAG(
    dag_id = 'pipeline_with_file_sensor',
    description = 'Running a pipeline using a file sensor',
    default_args = default_args,
    start_date = days_ago(1),
    schedule_interval = '@once',
    tags = ['pipeline', 'sensor', 'file sensor'],
    template_searchpath = '/Users/loonycorn/airflow/sql_statements'
) as dag:
    create_table_laptop = PostgresOperator(
        task_id = 'create_table_laptop',
        postgres_conn_id = 'postgres_connection_laptop_db',
        sql = 'create_table_laptops.sql'
    )

    checking_for_file = FileSensor(
        task_id = 'checking_for_file',
        filepath = FILE_PATH,
        poke_interval = 10,
        timeout = 60 * 10
    )
    
    insert_laptop_data = PythonOperator(
        task_id = 'insert_laptop_data',
        python_callable = insert_laptop_data
    )

    filter_gaming_laptops = PythonOperator(
        task_id = 'filter_gaming_laptops',
        python_callable = filter_gaming_laptops
    )

    filter_notebook_laptops = PythonOperator(
        task_id = 'filter_notebook_laptops',
        python_callable = filter_notebook_laptops
    )

    filter_ultrabook_laptops = PythonOperator(
        task_id = 'filter_ultrabook_laptops',
        python_callable = filter_ultrabook_laptops
    )

    delete_file = BashOperator(
        task_id = 'delete_file',
        bash_command = 'rm {0}'.format(FILE_PATH)
    )
    

    create_table_laptop >> checking_for_file >> insert_laptop_data >> \
    [filter_gaming_laptops, filter_notebook_laptops, filter_ultrabook_laptops] >> \
    delete_file


# Have one terminal open to psql

# On another screen have the Finder window showing the airflow/ page

# Show that we have an airflow/tmp folder that is empty

# On the third scren have the Airflow UI

# Go to the UI and show the DAG

# Show the Grid 

# Go to the Graph

# Unpause and auto-refresh the DAG

# Show that the file sensor is waiting for the files

# Show the logs for the File sensor

# Wait a bit and show that it's poking for the files

# Go back to the graph

# Now add laptops_01 and laptops_02 to the tmp/ folder

# Go back to the graph and show the DAG executing

# Once complete go to the terminal with psql

# Run this query - should show 40 records

SELECT * from laptops;

# Show the tmp/ folder is empty

# Show the contents of the 3 files in the output/ folder

# Back to the UI - trigger the DAG again

# Now add laptops_03, laptops_04, laptops_05 to the tmp folder

# Go back to the graph and show the DAG executing

# Once execution is complete go to the Finder window

# Show the tmp/ folder is empty

# Show the contents of the 3 files in the output/ folder
























