
# Open a terminal
$ python --version
# We are running Python 3.9.13

# https://airflow.apache.org/docs/apache-airflow/2.0.1/installation.html
# It is recomended to use python version 3.6, 3.7 or 3.8

# Airflow is tested with 3.7, 3.8, 3.9, 3.10

$ conda env list
# This will list all the enviroment present

# Now lets switch the enviroment from 3.9 to 3.7
$ conda activate /opt/anaconda3/envs/python37

$ python --version
# We are running Python 3.7.15


-------------------------------------------------------------------------------

$ airflow version

$ cd /Users/loonycorn/airflow

$ ls -l

# Observe we have airflow.cfg this is the main configuration file


# Show the airflow.cfg file especially where we have "load_examples = False"


# There should also be a SQLite DB


$ airflow users list
# id | username  | email                    | first_name | last_name | roles
# ===+===========+==========================+============+===========+======
# 1  | loonycorn | cloud.user@loonycorn.com | loonycorn  | loonycorn | Admin


$ airflow scheduler

# If the below question is asked type "y" and hit the return key
# Please confirm database initialize (or wait 4 seconds to skip it). Are you sure? [y/N]

# Scheduler (as we saw above in cfg file we are using SequentialExecutor) monitors all tasks 
# and DAGs and stays in sync with a folder for all DAG objects to
# collects DAG parsing results to trigger active tasks

# Open another tab in the terminal
$ conda activate /opt/anaconda3/envs/python37

$ airflow webserver

# If the below question is asked type "y" and hit the return key
# Please confirm database initialize (or wait 4 seconds to skip it). Are you sure? [y/N]

# Observe the host "Host: 0.0.0.0:8080"








