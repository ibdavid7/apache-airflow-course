--------------------------------------------------------------------
# Install and set up PostgreSQL
--------------------------------------------------------------------

# In browser goto "https://postgresapp.com/"

# Scroll and show the details on this page

# Click on "Downloads" -> "Postgres.app with PostgreSQL 15 (Universal)"

# Click "Download"

# Once downloaded move the app to "Application Folder" 

# Open "Postgres.app"

# Click "Initialize" to create a new server

# Click on server settings and show the details of the server

------------------------------------

# Go back to the terminal where you have your scheduler and webserver running

# Kill the scheduler and the web server

# Open up a new tab on that terminal


$ sudo mkdir -p /etc/paths.d &&
echo /Applications/Postgres.app/Contents/Versions/latest/bin | sudo tee /etc/paths.d/postgresapp

$ conda activate /opt/anaconda3/envs/python37

# psycopg2-binary is a Python library that provides a PostgreSQL adapter for Python. It allows Python programs to interact with PostgreSQL databases, enabling tasks such as connecting to a PostgreSQL database, executing SQL queries, and managing database transactions.

$ pip install psycopg2-binary


# The apache-airflow-providers-postgres library is an Apache Airflow provider package specifically designed for working with PostgreSQL databases. It provides a set of operators, hooks, and other components that facilitate integrating Apache Airflow with PostgreSQL.

# This provider package serves as an extension to Apache Airflow, offering enhanced functionality and support for PostgreSQL-related tasks within Airflow workflows. It leverages the underlying psycopg2 library to interact with PostgreSQL databases.

$ pip install apache-airflow-providers-postgres


----------------------------------------------------------

# IMPORTANT: Inside the psql shell please keep using this command to clear the screen as needed so you are always working at the top of the screen

$ \! clear


# Close the terminal and re-open

$ conda activate /opt/anaconda3/envs/python37

$ psql
# This will let us access the postgres interface 

$ \?
# This will list all the command that can be use in psql

$ \l
# This will list all the available databases


# Let us create a new database
$ CREATE DATABASE customers_db;

$ \l


$ \c customers_db
# This will connect to customers database

$ \dt
# This will list all the tables in this case there are no tables created


# https://postgresapp.com/documentation/configuration-general.html
$ SELECT * from user;
# This will list all the users
#    user    
# -----------
#  loonycorn
# Seems like there is one user loonycorn this is the default user that will be created 
# when installing postgres. Note this user will not have a password by default.
# So we will alter the user to have a password password as shown below


$ ALTER USER loonycorn PASSWORD 'password';


----------------------------------------------------------------------------

# Start the scheduler and web server (we've already installed the Postgres dependencies)


# Go to the Airflow UI

# Go to 

Admin -> Providers

# Note that the PostgreSQL provider is listed here

# Now go to 

Admin -> Connections



# Click on "+" button

Connection Id -> postgres_connection
Connection Type -> Postgres
Description -> Connecting to PostgreSQL running on localhost
Host -> localhost
Schema -> customers_db
Login -> loonycorn
Password -> password
Port -> 5432

# Click "Test" to check if the parameters provided are correct. We get
# the following output

# Connection successfully tested

# Click "Save"

# Scroll and show that the connection has been added to the list

---------------------------------------------------------------------------
# Version 01
---------------------------------------------------------------------------

# Now in VSCode create a new folder under airflow/ called sql_statements

airflow/sql_statements

# Show two files there


create_table_customers.sql
create_table_customer_purchases.sql


# Show the contents of the files

# create_table_customers.sql

CREATE TABLE IF NOT EXISTS customers(
            id INTEGER PRIMARY KEY,
            name VARCHAR(50) NOT NULL
        );

# create_table_customer_purchases.sql

CREATE TABLE IF NOT EXISTS customer_purchases(
    id INTEGER PRIMARY KEY,
    product VARCHAR(100) NOT NULL,
    price INTEGER NOT NULL,
    customer_id INTEGER NOT NULL REFERENCES customers (id)
);


# Now show the DAG code under dags/

from datetime import datetime, timedelta
from airflow.utils.dates import days_ago

from airflow import DAG
from airflow.providers.postgres.operators.postgres import PostgresOperator


default_args = {
   'owner': 'loonycorn'
}


with DAG(
    dag_id = 'postgres_pipeline',
    description = 'Running a pipeline using the Postgres operator',
    default_args = default_args,
    start_date = days_ago(1),
    schedule_interval = '@once',
    tags = ['operator', 'postgres'],
    template_searchpath = '/Users/loonycorn/airflow/sql_statements'
) as dag:

    create_table_customers = PostgresOperator(
        task_id = 'create_table_customers',
        postgres_conn_id = 'postgres_connection',
        sql = 'create_table_customers.sql'
    )

    create_table_customer_purchases = PostgresOperator(
        task_id = 'create_table_customer_purchases',
        postgres_conn_id = 'postgres_connection',
        sql = 'create_table_customer_purchases.sql'
    )

    create_table_customers >> create_table_customer_purchases




# Switch over to the Airflow UI

# Click through to the DAG in the GridView and show the tasks on the left

# Click on the GraphView and show the DAG (make sure you zoom out)

# Enable the DAG and enable Auto-refresh

# The DAG should run through fine

# Clikc on each task and show "Logs" and "Rendered Templates"



# Go back to the termianl where we had connected to Postgres

# Show the tables
$ \dt
#  Schema |     Name      | Type  |   Owner   
# --------+---------------+-------+-----------
#  public | customer_info | table | loonycorn


# Observe we have created two tables successfully

# Show the schema for each table

$ \d customers


$ \d customer_purchases


# Let's drop the tables before we update the DAG

# Customer purchases has to be dropped first because it has a foreign key referencing customers

DROP TABLE customer_purchases;

DROP TABLE customers;


---------------------------------------------------------------------------
# Version 02
---------------------------------------------------------------------------

# Show two new files in the sql_statements/ folder

insert_customers.sql
insert_customer_purchases.sql


# insert_customers.sql

INSERT INTO customers (id, name) VALUES (1, 'Janice Smith');
INSERT INTO customers (id, name) VALUES (2, 'Ronald Jones');
INSERT INTO customers (id, name) VALUES (3, 'Kiele West');
INSERT INTO customers (id, name) VALUES (4, 'Leonard Cruise');
INSERT INTO customers (id, name) VALUES (5, 'Rihanna Luis');
INSERT INTO customers (id, name) VALUES (6, 'Koma Day-Lewis');



# insert_customer_purchases.sql


INSERT INTO customer_purchases (id, product, price, customer_id) 
VALUES (1, 'Bread - Hamburger Buns', 6.14, 1);
INSERT INTO customer_purchases (id, product, price, customer_id) 
VALUES (2, 'Muffin Batt - Ban Dream Zero', 5.95, 2);
INSERT INTO customer_purchases (id, product, price, customer_id) 
VALUES (3, 'Pastry - Choclate Baked', 2.2, 1);
INSERT INTO customer_purchases (id, product, price, customer_id) 
VALUES (4, 'Placemat - Scallop, White', 8.07, 6);
INSERT INTO customer_purchases (id, product, price, customer_id) 
VALUES (5, 'Sauerkraut', 7.34, 3);
INSERT INTO customer_purchases (id, product, price, customer_id) 
VALUES (6, 'Wine - Mondavi Coastal Private', 2.69, 2);
INSERT INTO customer_purchases (id, product, price, customer_id) 
VALUES (7, 'Pepper - Chilli Seeds Mild', 4.44, 1);
INSERT INTO customer_purchases (id, product, price, customer_id) 
VALUES (8, 'Straw - Regular', 2.69, 3);
INSERT INTO customer_purchases (id, product, price, customer_id) 
VALUES (9, 'Cheese - Colby', 6.12, 4);
INSERT INTO customer_purchases (id, product, price, customer_id) 
VALUES (10, 'Croissant, Raw - Mini', 7.98, 2);
INSERT INTO customer_purchases (id, product, price, customer_id) 
VALUES (11, 'Wine - Chardonnay South', 3.47, 5);
INSERT INTO customer_purchases (id, product, price, customer_id) 
VALUES (12, 'Bar Nature Valley', 6.11, 6);
INSERT INTO customer_purchases (id, product, price, customer_id) 
VALUES (13, 'Clementine', 1.78, 4);
INSERT INTO customer_purchases (id, product, price, customer_id) 
VALUES (14, 'Sole - Fillet', 2.18, 2);
INSERT INTO customer_purchases (id, product, price, customer_id) 
VALUES (15, 'Lemon Tarts', 3.97, 1);
INSERT INTO customer_purchases (id, product, price, customer_id) 
VALUES (16, 'Creamers - 10%', 3.14, 1);
INSERT INTO customer_purchases (id, product, price, customer_id) 
VALUES (17, 'Mushroom - Trumpet, Dry', 5.17, 3);
INSERT INTO customer_purchases (id, product, price, customer_id) 
VALUES (18, 'Duck - Breast', 9.66, 5);
INSERT INTO customer_purchases (id, product, price, customer_id) 
VALUES (19, 'Thyme - Fresh', 4.14, 1);
INSERT INTO customer_purchases (id, product, price, customer_id) 
VALUES (20, 'Nescafe - Frothy French Vanilla', 7.87, 2);


# postgres_pipeline.py

from datetime import datetime, timedelta
from airflow.utils.dates import days_ago

from airflow import DAG
from airflow.providers.postgres.operators.postgres import PostgresOperator


default_args = {
   'owner': 'loonycorn'
}


with DAG(
    dag_id = 'postgres_pipeline',
    description = 'Running a pipeline using the Postgres operator',
    default_args = default_args,
    start_date = days_ago(1),
    schedule_interval = '@once',
    tags = ['operator', 'postgres'],
    template_searchpath = '/Users/loonycorn/airflow/sql_statements'
) as dag:

    create_table_customers = PostgresOperator(
        task_id = 'create_table_customers',
        postgres_conn_id = 'postgres_connection',
        sql = 'create_table_customers.sql'
    )

    create_table_customer_purchases = PostgresOperator(
        task_id = 'create_table_customer_purchases',
        postgres_conn_id = 'postgres_connection',
        sql = 'create_table_customer_purchases.sql'
    )

    insert_customers = PostgresOperator(
        task_id = 'insert_customers',
        postgres_conn_id = 'postgres_connection',
        sql = 'insert_customers.sql'
    )

    insert_customer_purchases = PostgresOperator(
        task_id = 'insert_customer_purchases',
        postgres_conn_id = 'postgres_connection',
        sql = 'insert_customer_purchases.sql'
    )

    create_table_customers >> create_table_customer_purchases >> \
        insert_customers >> insert_customer_purchases




# Switch over to the Airflow UI

# Click through to the DAG in the GridView and show the tasks on the left

# Click on the GraphView and show the DAG (make sure you zoom out)

# Trigger the DAG

# Click on each "insert" task and show "Logs" and "Rendered Templates"



# Go back to the terminal where we had connected to Postgres

# Show the tables
$ \dt


# Observe we have created two tables successfully

# Query the tables


SELECT * FROM customers;


SELECT * FROM customer_purchases;


# Let's drop the tables before we update the DAG

# Customer purchases has to be dropped first because it has a foreign key referencing customers

DROP TABLE customer_purchases;

DROP TABLE customers;



---------------------------------------------------------------------------
# Version 03
---------------------------------------------------------------------------

# Show one files in the sql_statements/ folder


joining_table.sql

# joining_table.sql


CREATE TABLE complete_customer_details
AS
SELECT customers.id, 
       customers.name, 
       customer_purchases.product, 
       customer_purchases.price
FROM customers RIGHT JOIN customer_purchases
ON customers.id = customer_purchases.customer_id;


# postgres_pipeline.py

from datetime import datetime, timedelta
from airflow.utils.dates import days_ago

from airflow import DAG
from airflow.providers.postgres.operators.postgres import PostgresOperator


default_args = {
   'owner': 'loonycorn'
}


with DAG(
    dag_id = 'postgres_pipeline',
    description = 'Running a pipeline using the Postgres operator',
    default_args = default_args,
    start_date = days_ago(1),
    schedule_interval = '@once',
    tags = ['operator', 'postgres'],
    template_searchpath = '/Users/loonycorn/airflow/sql_statements'
) as dag:

    create_table_customers = PostgresOperator(
        task_id = 'create_table_customers',
        postgres_conn_id = 'postgres_connection',
        sql = 'create_table_customers.sql'
    )

    create_table_customer_purchases = PostgresOperator(
        task_id = 'create_table_customer_purchases',
        postgres_conn_id = 'postgres_connection',
        sql = 'create_table_customer_purchases.sql'
    )

    insert_customers = PostgresOperator(
        task_id = 'insert_customers',
        postgres_conn_id = 'postgres_connection',
        sql = 'insert_customers.sql'
    )

    insert_customer_purchases = PostgresOperator(
        task_id = 'insert_customer_purchases',
        postgres_conn_id = 'postgres_connection',
        sql = 'insert_customer_purchases.sql'
    )


    joining_table = PostgresOperator(
        task_id = 'joining_table',
        postgres_conn_id = 'postgres_connection',
        sql = 'joining_table.sql'
    )

    filtering_customers = PostgresOperator(
        task_id = 'filtering_customers',
        postgres_conn_id = 'postgres_connection',
        sql = '''
            SELECT name, product, price
            FROM complete_customer_details
            WHERE price BETWEEN %(lower_bound)s AND %(upper_bound)s
        ''',
        parameters = {'lower_bound': 5, 'upper_bound': 9}
    )

    create_table_customers >> create_table_customer_purchases >> \
        insert_customers >> insert_customer_purchases >> \
        joining_table >> filtering_customers



# Switch over to the Airflow UI

# Click through to the DAG in the GridView and show the tasks on the left

# Click on the GraphView and show the DAG (make sure you zoom out)

# Trigger the DAG

# Click on each "joining_table" task and show "Logs" and "Rendered Templates"


# Click on each "filtering_customers" task and show "Logs" and "Rendered Templates" and "XCom"


# Go back to the terminal where we had connected to Postgres

# Show the tables
$ \dt


# Observe we have created two tables successfully

# Query the table


SELECT * FROM complete_customer_details;


# Let's drop the tables before we update the DAG

# Customer purchases has to be dropped first because it has a foreign key referencing customers

DROP TABLE complete_customer_details;

DROP TABLE customer_purchases;

DROP TABLE customers;




---------------------------------------------------------------------------
# Version 04
---------------------------------------------------------------------------

# Show that the output directory is present under airflow

airflow/output

# Show the updated code with a Python operator and corresponding imports

from datetime import datetime, timedelta
from airflow.utils.dates import days_ago

from airflow import DAG
from airflow.providers.postgres.operators.postgres import PostgresOperator
from airflow.operators.python import PythonOperator

import csv

default_args = {
   'owner': 'loonycorn'
}


def saving_to_csv(ti):
    filter_data = ti.xcom_pull(task_ids='filtering_customers')

    with open('/Users/loonycorn/airflow/output/filtered_customer_data.csv', 
              'w', newline='') as file:

        writer = csv.writer(file)

        writer.writerow(['Name', 'Product', 'Price'])

        for row in filter_data:
            writer.writerow(row)

with DAG(
    dag_id = 'postgres_pipeline',
    description = 'Running a pipeline using the Postgres operator',
    default_args = default_args,
    start_date = days_ago(1),
    schedule_interval = '@once',
    tags = ['operator', 'postgres'],
    template_searchpath = '/Users/jananiravi/airflow/sql_statements'
) as dag:

    create_table_customers = PostgresOperator(
        task_id = 'create_table_customers',
        postgres_conn_id = 'postgres_connection',
        sql = 'create_table_customers.sql'
    )

    create_table_customer_purchases = PostgresOperator(
        task_id = 'create_table_customer_purchases',
        postgres_conn_id = 'postgres_connection',
        sql = 'create_table_customer_purchases.sql'
    )

    insert_customers = PostgresOperator(
        task_id = 'insert_customers',
        postgres_conn_id = 'postgres_connection',
        sql = 'insert_customers.sql'
    )

    insert_customer_purchases = PostgresOperator(
        task_id = 'insert_customer_purchases',
        postgres_conn_id = 'postgres_connection',
        sql = 'insert_customer_purchases.sql'
    )


    joining_table = PostgresOperator(
        task_id = 'joining_table',
        postgres_conn_id = 'postgres_connection',
        sql = 'joining_table.sql'
    )

    filtering_customers = PostgresOperator(
        task_id = 'filtering_customers',
        postgres_conn_id = 'postgres_connection',
        sql = '''
            SELECT name, product, price
            FROM complete_customer_details
            WHERE price BETWEEN %(lower_bound)s AND %(upper_bound)s
        ''',
        parameters = {'lower_bound': 5, 'upper_bound': 9}
    )

    saving_to_csv = PythonOperator(
        task_id='saving_to_csv',
        python_callable=saving_to_csv
    )


    create_table_customers >> create_table_customer_purchases >> \
        insert_customers >> insert_customer_purchases >> \
        joining_table >> filtering_customers >> saving_to_csv




# Switch over to the Airflow UI

# Click through to the DAG in the GridView and show the tasks on the left

# Click on the GraphView and show the DAG (make sure you zoom out)

# Trigger the DAG


# Go back to the terminal where we had connected to Postgres

# Show the tables
$ \dt


SELECT * FROM complete_customer_details;

# Go to airflow/output


# Show the filtered_customer_data.csv file




---------------------------------------------------------------------------
# Version 05
---------------------------------------------------------------------------


# Change only this task in the file postgres_pipeline.py


    filtering_customers = PostgresOperator(
        task_id = 'filtering_customers',
        postgres_conn_id = 'postgres_connection',
        sql='''
            SELECT name, product, price
            FROM complete_customer_details
            WHERE name = ANY(%(names)s)
        ''',
        parameters={'names': ['Kiele West', 'Koma Day-Lewis']}
    )


# > click on "filtering" task in grid view and click "clear"


# > this will run the task from filtering only


# Show the filtered_customer_data.csv file


# In the psql terminal drop the databases


DROP TABLE complete_customer_details;

DROP TABLE customer_purchases;

DROP TABLE customers;










