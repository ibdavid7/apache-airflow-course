-------------------------------------------------------------------------
# Setting up Postgres as the metadata database
-------------------------------------------------------------------------

############ Notes: --------------------
# LocalExecutor: The LocalExecutor executes task instances in separate processes on the same machine where the Airflow scheduler is running. Each task instance runs independently, and they are executed concurrently up to the configured concurrency limit. The LocalExecutor allows for parallel execution of tasks on a single machine, but it doesn't provide distributed processing across multiple machines.
############ Notes: --------------------


# Before we start this demo show the main Airflow UI

# Note that we have two warnings talking about the metadata database

# This is what we will fix

# In terminal

$ psql

# creating a database called airflow_db
$ CREATE DATABASE airflow_db;

# Open up airflow.cfg in Sublimetext

# airflow.cfg

executor = LocalExecutor
sql_alchemy_conn = postgresql://loonycorn:password@localhost:5432/airflow_db


# Kill the scheduler and the web server

# In the scheduler terminal run

airflow db init


# There should be no users
airflow users list

# Create a user for the web server

airflow users create \
-e cloud.user@loonycorn.com \
-f CloudUser \
-l Loonycorn \
-p password \
-r Admin \
-u cloud.user 

# There should be one user
airflow users list


# Restart the scheduler and the web server


# Go to localhost:8080

# Login with cloud.user and password

# The last DAG postgres_pipeline should still be there


 Now go to 

Admin -> Connections



# Click on "+" button

Connection Id -> postgres_connection
Connection Type -> Postgres
Description -> Connecting to PostgreSQL running on localhost
Host -> localhost
Schema -> customers_db
Login -> loonycorn
Password -> password
Port -> 5432

# Click "Test" to check if the parameters provided are correct. We get
# the following output

# Connection successfully tested

# Click "Save"


# Click through should the Grid

# Go to the Graph view

# Trigger the DAG

# Notice multiple tasks will be started in parallel

# Things should run through successfully

































