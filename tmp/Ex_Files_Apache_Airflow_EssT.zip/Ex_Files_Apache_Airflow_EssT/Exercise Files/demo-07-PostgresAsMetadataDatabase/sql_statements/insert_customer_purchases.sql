INSERT INTO customer_purchases (id, product, price, customer_id) 
VALUES (1, 'Bread - Hamburger Buns', 6.14, 1);
INSERT INTO customer_purchases (id, product, price, customer_id) 
VALUES (2, 'Muffin Batt - Ban Dream Zero', 5.95, 2);
INSERT INTO customer_purchases (id, product, price, customer_id) 
VALUES (3, 'Pastry - Choclate Baked', 2.2, 1);
INSERT INTO customer_purchases (id, product, price, customer_id) 
VALUES (4, 'Placemat - Scallop, White', 8.07, 6);
INSERT INTO customer_purchases (id, product, price, customer_id) 
VALUES (5, 'Sauerkraut', 7.34, 3);
INSERT INTO customer_purchases (id, product, price, customer_id) 
VALUES (6, 'Wine - Mondavi Coastal Private', 2.69, 2);
INSERT INTO customer_purchases (id, product, price, customer_id) 
VALUES (7, 'Pepper - Chilli Seeds Mild', 4.44, 1);
INSERT INTO customer_purchases (id, product, price, customer_id) 
VALUES (8, 'Straw - Regular', 2.69, 3);
INSERT INTO customer_purchases (id, product, price, customer_id) 
VALUES (9, 'Cheese - Colby', 6.12, 4);
INSERT INTO customer_purchases (id, product, price, customer_id) 
VALUES (10, 'Croissant, Raw - Mini', 7.98, 2);
INSERT INTO customer_purchases (id, product, price, customer_id) 
VALUES (11, 'Wine - Chardonnay South', 3.47, 5);
INSERT INTO customer_purchases (id, product, price, customer_id) 
VALUES (12, 'Bar Nature Valley', 6.11, 6);
INSERT INTO customer_purchases (id, product, price, customer_id) 
VALUES (13, 'Clementine', 1.78, 4);
INSERT INTO customer_purchases (id, product, price, customer_id) 
VALUES (14, 'Sole - Fillet', 2.18, 2);
INSERT INTO customer_purchases (id, product, price, customer_id) 
VALUES (15, 'Lemon Tarts', 3.97, 1);
INSERT INTO customer_purchases (id, product, price, customer_id) 
VALUES (16, 'Creamers - 10%', 3.14, 1);
INSERT INTO customer_purchases (id, product, price, customer_id) 
VALUES (17, 'Mushroom - Trumpet, Dry', 5.17, 3);
INSERT INTO customer_purchases (id, product, price, customer_id) 
VALUES (18, 'Duck - Breast', 9.66, 5);
INSERT INTO customer_purchases (id, product, price, customer_id) 
VALUES (19, 'Thyme - Fresh', 4.14, 1);
INSERT INTO customer_purchases (id, product, price, customer_id) 
VALUES (20, 'Nescafe - Frothy French Vanilla', 7.87, 2);
