INSERT INTO customers (id, name) VALUES (1, 'Janice Smith');
INSERT INTO customers (id, name) VALUES (2, 'Ronald Jones');
INSERT INTO customers (id, name) VALUES (3, 'Kiele West');
INSERT INTO customers (id, name) VALUES (4, 'Leonard Cruise');
INSERT INTO customers (id, name) VALUES (5, 'Rihanna Luis');
INSERT INTO customers (id, name) VALUES (6, 'Koma Day-Lewis');
