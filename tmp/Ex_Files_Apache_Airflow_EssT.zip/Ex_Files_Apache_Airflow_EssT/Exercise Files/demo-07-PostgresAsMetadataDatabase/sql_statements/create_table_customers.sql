CREATE TABLE IF NOT EXISTS customers(
            id INTEGER PRIMARY KEY,
            name VARCHAR(50) NOT NULL
        );